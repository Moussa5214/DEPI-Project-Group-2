package tests;

import base.BaseTest;
import org.testng.annotations.Test;
import pages.LoginPage;
import org.testng.Assert;

public class LoginTest extends BaseTest {

    @Test
    public void validLoginTest() {
        LoginPage login = new LoginPage(driver);
        login.login("standard_user", "secret_sauce");

        String url = driver.getCurrentUrl();
        Assert.assertTrue(url.contains("inventory.html"), "Login failed!");
    }
}