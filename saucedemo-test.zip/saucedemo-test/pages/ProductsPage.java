package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import java.util.List;
import org.openqa.selenium.WebElement;

public class ProductsPage {
    private WebDriver driver;

    private By productItems = By.className("inventory_item");
    private By productNames = By.className("inventory_item_name");

    public ProductsPage(WebDriver driver) {
        this.driver = driver;
    }

    public int getProductCount() {
        return driver.findElements(productItems).size();
    }

    public void clickProductByName(String name) {
        List<WebElement> products = driver.findElements(productNames);
        for (WebElement product : products) {
            if (product.getText().equalsIgnoreCase(name)) {
                product.click();
                break;
            }
        }
    }

    public boolean productExists(String name) {
        return driver.findElements(By.xpath("//div[text()='" + name + "']")).size() > 0;
    }
}